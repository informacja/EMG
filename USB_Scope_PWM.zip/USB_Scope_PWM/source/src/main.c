/*
 * @brief USB Scope
 *
 * @note
 * Copyright(C) PWSZ Tarnow, 2018
 *
 *
 */

#include "board.h"
#include <stdio.h>
#include <string.h>
#include <arm_math.h>
#include "app_usbd_cfg.h"
#include "cdc_vcom.h"


#define GET_BIT(k, n)     (k &   (1 << (n)))
#define SET_BIT(k, n)     (k |=  (1 << (n)))
#define CLR_BIT(k, n)     (k &= ~(1 << (n)))

#define PWMFS		10000
#define FS			10240
#define NRX			4
#define NTX			2048
#define NCH			3

#define DSIZE 		(NTX*NCH)
#define DSIZE2 		(DSIZE/2)
#define PSIZE 		32
#define SSIZE 		(DSIZE/PSIZE)
#define _LPC_ADC_ID LPC_ADC

static USBD_HANDLE_T g_hUsb;
static uint8_t g_rxBuff[4];
static uint8_t g_txBuff[DSIZE];
const  USBD_API_T *g_pUsbApi;

unsigned int wr=0;
uint16_t *data=(uint16_t*)g_txBuff;
uint16_t dataADC0=0, dataADC1=0, dataADC2=0;
volatile bool dataCapture=false, captureReady=false, trigger=false;

/**
 * @brief	Handle interrupt from USB0
 * @return	Nothing
 */
void USB_IRQHandler(void)
{
	uint32_t *addr = (uint32_t *) LPC_USB->EPLISTSTART;

	/*	WORKAROUND for artf32289 ROM driver BUG:
	    As part of USB specification the device should respond
	    with STALL condition for any unsupported setup packet. The host will send
	    new setup packet/request on seeing STALL condition for EP0 instead of sending
	    a clear STALL request. Current driver in ROM doesn't clear the STALL
	    condition on new setup packet which should be fixed.
	 */
	if ( LPC_USB->DEVCMDSTAT & _BIT(8) ) {	/* if setup packet is received */
		addr[0] &= ~(_BIT(29));	/* clear EP0_OUT stall */
		addr[2] &= ~(_BIT(29));	/* clear EP0_IN stall */
	}
	USBD_API->hw->ISR(g_hUsb);
}

/* Find the address of interface descriptor for given class type. */
USB_INTERFACE_DESCRIPTOR *find_IntfDesc(const uint8_t *pDesc, uint32_t intfClass)
{
	USB_COMMON_DESCRIPTOR *pD;
	USB_INTERFACE_DESCRIPTOR *pIntfDesc = 0;
	uint32_t next_desc_adr;

	pD = (USB_COMMON_DESCRIPTOR *) pDesc;
	next_desc_adr = (uint32_t) pDesc;

	while (pD->bLength) {
		/* is it interface descriptor */
		if (pD->bDescriptorType == USB_INTERFACE_DESCRIPTOR_TYPE) {

			pIntfDesc = (USB_INTERFACE_DESCRIPTOR *) pD;
			/* did we find the right interface descriptor */
			if (pIntfDesc->bInterfaceClass == intfClass) {
				break;
			}
		}
		pIntfDesc = 0;
		next_desc_adr = (uint32_t) pD + pD->bLength;
		pD = (USB_COMMON_DESCRIPTOR *) next_desc_adr;
	}

	return pIntfDesc;
}
/*---------------------------------------------------------------------------*/
/* Timer 16_0 Interrupt */
void TIMER16_0_IRQHandler(void)
{
	if (Chip_TIMER_MatchPending(LPC_TIMER16_0, 3)) {
		Chip_TIMER_ClearMatch(LPC_TIMER16_0, 3);

		trigger=true;
	}
}
/*---------------------------------------------------------------------------*/
/* ADC Interrupt */
void ADC_IRQHandler(void){

	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH0, &dataADC0);
	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH1, &dataADC1);
	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH2, &dataADC2);

	if(dataCapture & trigger){

		data[wr++]=(dataADC0<<4);
		data[wr++]=(dataADC1<<4);
		data[wr++]=(dataADC2<<4);

		if(wr>=DSIZE2){
			dataCapture=false;
			captureReady=true;
			wr=0;
		}
	}
}
/*---------------------------------------------------------------------------*/
int main(void)
{
	static ADC_CLOCK_SETUP_T ADCSetup;
	uint32_t timerFreq;

	USBD_API_INIT_PARAM_T usb_param;
	USB_CORE_DESCS_T desc;
	ErrorCode_t ret = LPC_OK;
	uint32_t prompt = 0, rdSize = 0;

	SystemCoreClockUpdate();
	/* Initialize board and chip */
	Board_Init();

	/* enable clocks and pinmux */
	Chip_USB_Init();

	/* initialize USBD ROM API pointer. */
	g_pUsbApi = (const USBD_API_T *) LPC_ROM_API->usbdApiBase;

	/* initialize call back structures */
	memset((void *) &usb_param, 0, sizeof(USBD_API_INIT_PARAM_T));
	usb_param.usb_reg_base = LPC_USB0_BASE;
	/*	WORKAROUND for artf44835 ROM driver BUG:
	    Code clearing STALL bits in endpoint reset routine corrupts memory area
	    next to the endpoint control data. For example When EP0, EP1_IN, EP1_OUT,
	    EP2_IN are used we need to specify 3 here. But as a workaround for this
	    issue specify 4. So that extra EPs control structure acts as padding buffer
	    to avoid data corruption. Corruption of padding memory doesn’t affect the
	    stack/program behaviour.
	 */
	usb_param.max_num_ep = 3 + 1;
	usb_param.mem_base = USB_STACK_MEM_BASE;
	usb_param.mem_size = USB_STACK_MEM_SIZE;

	/* Set the USB descriptors */
	desc.device_desc = (uint8_t *) &USB_DeviceDescriptor[0];
	desc.string_desc = (uint8_t *) &USB_StringDescriptor[0];
	/* Note, to pass USBCV test full-speed only devices should have both
	   descriptor arrays point to same location and device_qualifier set to 0.
	 */
	desc.high_speed_desc = (uint8_t *) &USB_FsConfigDescriptor[0];
	desc.full_speed_desc = (uint8_t *) &USB_FsConfigDescriptor[0];
	desc.device_qualifier = 0;

	/* USB Initialization */
	ret = USBD_API->hw->Init(&g_hUsb, &desc, &usb_param);
	if (ret == LPC_OK) {

		/*	WORKAROUND for artf32219 ROM driver BUG:
		    The mem_base parameter part of USB_param structure returned
		    by Init() routine is not accurate causing memory allocation issues for
		    further components.
		 */
		usb_param.mem_base = USB_STACK_MEM_BASE + (USB_STACK_MEM_SIZE - usb_param.mem_size);

		/* Init VCOM interface */
		ret = vcom_init(g_hUsb, &desc, &usb_param);
		if (ret == LPC_OK) {
			/*  enable USB interrupts */
			NVIC_EnableIRQ(USB0_IRQn);
			/* now connect */
			USBD_API->hw->Connect(g_hUsb, 1);
		}
	}
	/*-------------------- ADC Init --------------------*/
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 11, (IOCON_FUNC2 | IOCON_ADMODE_EN)); /* AD0 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 12, (IOCON_FUNC2 | IOCON_ADMODE_EN)); /* AD1 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 13, (IOCON_FUNC2 | IOCON_ADMODE_EN)); /* AD2 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 14, (IOCON_FUNC2 | IOCON_ADMODE_EN)); /* AD3 */

	Chip_ADC_Init(_LPC_ADC_ID, &ADCSetup);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH0, ENABLE);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH1, ENABLE);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH2, ENABLE);
	Chip_ADC_Int_SetChannelCmd(_LPC_ADC_ID, ADC_CH2, ENABLE);
	NVIC_SetPriority(ADC_IRQn, 0);
	NVIC_ClearPendingIRQ(ADC_IRQn);
	NVIC_EnableIRQ(ADC_IRQn);
	Chip_ADC_SetStartMode(_LPC_ADC_ID, ADC_START_ON_ADCTRIG0, ADC_TRIGGERMODE_RISING);

	/*-------------------- Timer32_0  Init --------------------*/
	Chip_TIMER_Init(LPC_TIMER32_0);
	timerFreq = Chip_Clock_GetSystemClockRate();
	Chip_TIMER_Reset(LPC_TIMER32_0);
	Chip_TIMER_MatchEnableInt(LPC_TIMER32_0, 0);
	Chip_TIMER_SetMatch(LPC_TIMER32_0, 0, ((timerFreq / (2*FS*NCH))-1));
	Chip_TIMER_ResetOnMatchEnable(LPC_TIMER32_0, 0);
	Chip_TIMER_ExtMatchControlSet(LPC_TIMER32_0, 0, TIMER_EXTMATCH_TOGGLE, 0);
	Chip_TIMER_Enable(LPC_TIMER32_0);

	/*-------------------- Timer16_0  Init --------------------*/
	// PWM Pins
	Chip_IOCON_PinMuxSet(LPC_IOCON, 1, 13, IOCON_FUNC2 ); /* PIO1_13 connected to MAT0 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 1, 14, IOCON_FUNC2 ); /* PIO1_14 connected to MAT1 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 1, 15, IOCON_FUNC2 ); /* PIO1_15 connected to MAT2 */

	Chip_TIMER_Init(LPC_TIMER16_0);
	Chip_TIMER_PrescaleSet(LPC_TIMER16_0, (timerFreq/PWMFS)-1);
	Chip_TIMER_SetMatch(LPC_TIMER16_0, 0, 10);
	Chip_TIMER_SetMatch(LPC_TIMER16_0, 1, 30);
	Chip_TIMER_SetMatch(LPC_TIMER16_0, 2, 50);
	Chip_TIMER_SetMatch(LPC_TIMER16_0, 3, 99);// counter 0-99

	Chip_TIMER_ResetOnMatchEnable(LPC_TIMER16_0,  3);
	//	__IO uint32_t PWMC; //brak w strukturze LPC_TIMER_T
	LPC_TIMER16_0->PWMC=7;

	/* Enable timer interrupt */
	Chip_TIMER_MatchEnableInt(LPC_TIMER16_0, 3); /* MAT3 Int */
	NVIC_SetPriority(TIMER_16_0_IRQn, 1);
	NVIC_ClearPendingIRQ(TIMER_16_0_IRQn);
	NVIC_EnableIRQ(TIMER_16_0_IRQn);

	Chip_TIMER_Reset(LPC_TIMER16_0);
	Chip_TIMER_Enable(LPC_TIMER16_0);
	/*----------------------- End of Init ------------------------*/

	while (1) {
		/* Check if host has connected and opened the VCOM port */
		if ((vcom_connected() != 0) && (prompt == 0)) {

			prompt = 1;
			Board_LED_Set(0, true);
		}

		if (prompt) {

			rdSize = vcom_bread(&g_rxBuff[0], NRX);
			if (rdSize==NRX){

				Chip_TIMER_SetMatch(LPC_TIMER16_0, 0, 100-(unsigned int)g_rxBuff[1]);
				Chip_TIMER_SetMatch(LPC_TIMER16_0, 1, 100-(unsigned int)g_rxBuff[2]);
				Chip_TIMER_SetMatch(LPC_TIMER16_0, 2, 100-(unsigned int)g_rxBuff[3]);

				if(GET_BIT(g_rxBuff[0], 7)){

					if(!dataCapture){

						wr=0;
						dataCapture=true;
						if(GET_BIT(g_rxBuff[0], 6))
							trigger=false;
					}
				}
			}
			if(captureReady){

				captureReady=false;
				for(int i=0;i<SSIZE;i++)
					vcom_write(&g_txBuff[i*PSIZE], PSIZE);
			}
		}
	}
}
