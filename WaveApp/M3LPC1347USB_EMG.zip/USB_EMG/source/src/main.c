/*
 * @brief USB Scope
 *
 * @note
 * Copyright(C) PWSZ Tarnow, 2018
 *
 *
 */

#include "board.h"
#include <stdio.h>
#include <string.h>
#include <arm_math.h>
#include "app_usbd_cfg.h"
#include "cdc_vcom.h"



#define GET_BIT(k, n)     (k &   (1 << (n)))
#define SET_BIT(k, n)     (k |=  (1 << (n)))
#define CLR_BIT(k, n)     (k &= ~(1 << (n)))


#define FS			2048
#define NRX			1
#define NTX			256
#define NCH			8

#define DSIZE 		(NTX*NCH*2)
#define DSIZE2 		(DSIZE/2)
#define DSIZE4 		(DSIZE/4)
#define PSIZE 		32
#define SSIZE 		(DSIZE2/PSIZE)
#define _LPC_ADC_ID LPC_ADC

static USBD_HANDLE_T g_hUsb;
static uint8_t g_rxBuff[4];
static uint8_t g_txBuff[DSIZE];
const  USBD_API_T *g_pUsbApi;

unsigned int wr=0;
uint16_t *data=(uint16_t*)g_txBuff;
uint16_t dataADC0=0, dataADC1=0, dataADC2=0, dataADC3=0, dataADC4=0, dataADC5=0, dataADC6=0, dataADC7=0;
volatile bool dataCapture=false, captureReady1=false, captureReady2=false;


/**
 * @brief	Handle interrupt from USB0
 * @return	Nothing
 */
void USB_IRQHandler(void)
{
	uint32_t *addr = (uint32_t *) LPC_USB->EPLISTSTART;

	/*	WORKAROUND for artf32289 ROM driver BUG:
	    As part of USB specification the device should respond
	    with STALL condition for any unsupported setup packet. The host will send
	    new setup packet/request on seeing STALL condition for EP0 instead of sending
	    a clear STALL request. Current driver in ROM doesn't clear the STALL
	    condition on new setup packet which should be fixed.
	 */
	if ( LPC_USB->DEVCMDSTAT & _BIT(8) ) {	/* if setup packet is received */
		addr[0] &= ~(_BIT(29));	/* clear EP0_OUT stall */
		addr[2] &= ~(_BIT(29));	/* clear EP0_IN stall */
	}
	USBD_API->hw->ISR(g_hUsb);
}

/* Find the address of interface descriptor for given class type. */
USB_INTERFACE_DESCRIPTOR *find_IntfDesc(const uint8_t *pDesc, uint32_t intfClass)
{
	USB_COMMON_DESCRIPTOR *pD;
	USB_INTERFACE_DESCRIPTOR *pIntfDesc = 0;
	uint32_t next_desc_adr;

	pD = (USB_COMMON_DESCRIPTOR *) pDesc;
	next_desc_adr = (uint32_t) pDesc;

	while (pD->bLength) {
		/* is it interface descriptor */
		if (pD->bDescriptorType == USB_INTERFACE_DESCRIPTOR_TYPE) {

			pIntfDesc = (USB_INTERFACE_DESCRIPTOR *) pD;
			/* did we find the right interface descriptor */
			if (pIntfDesc->bInterfaceClass == intfClass) {
				break;
			}
		}
		pIntfDesc = 0;
		next_desc_adr = (uint32_t) pD + pD->bLength;
		pD = (USB_COMMON_DESCRIPTOR *) next_desc_adr;
	}

	return pIntfDesc;
}
/*---------------------------------------------------------------------------*/
/* ADC Interrupt */
void ADC_IRQHandler(void){

	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH0, &dataADC0);
	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH1, &dataADC1);
	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH2, &dataADC2);
	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH3, &dataADC3);
	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH4, &dataADC4);
	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH5, &dataADC5);
	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH6, &dataADC6);
	Chip_ADC_ReadValue(_LPC_ADC_ID, ADC_CH7, &dataADC7);

	if(dataCapture){

		data[wr++]=(dataADC0<<4);
		data[wr++]=(dataADC1<<4);
		data[wr++]=(dataADC2<<4);
		data[wr++]=(dataADC3<<4);
		data[wr++]=(dataADC4<<4);
		data[wr++]=(dataADC5<<4);
		data[wr++]=(dataADC6<<4);
		data[wr++]=(dataADC7<<4);

		if(wr==DSIZE4){

			if(captureReady1){
				Board_LED_Set(0, true);
				dataCapture=false;
			}
			captureReady1=true;

		}

		if(wr>=DSIZE2){

			if(captureReady2){
				Board_LED_Set(0, true);
				dataCapture=false;
			}
			captureReady2=true;
			wr=0;
		}
	}
}
/*---------------------------------------------------------------------------*/

/**
 * @brief	main routine for blinky example
 * @return	Function should not exit.
 */
int main(void)
{
	static ADC_CLOCK_SETUP_T ADCSetup;
	uint32_t timerFreq;


	USBD_API_INIT_PARAM_T usb_param;
	USB_CORE_DESCS_T desc;
	ErrorCode_t ret = LPC_OK;
	uint32_t prompt = 0, rdSize = 0;

	SystemCoreClockUpdate();
	/* Initialize board and chip */
	Board_Init();

	/* enable clocks and pinmux */
	Chip_USB_Init();

	/* initialize USBD ROM API pointer. */
	g_pUsbApi = (const USBD_API_T *) LPC_ROM_API->usbdApiBase;

	/* initialize call back structures */
	memset((void *) &usb_param, 0, sizeof(USBD_API_INIT_PARAM_T));
	usb_param.usb_reg_base = LPC_USB0_BASE;
	/*	WORKAROUND for artf44835 ROM driver BUG:
	    Code clearing STALL bits in endpoint reset routine corrupts memory area
	    next to the endpoint control data. For example When EP0, EP1_IN, EP1_OUT,
	    EP2_IN are used we need to specify 3 here. But as a workaround for this
	    issue specify 4. So that extra EPs control structure acts as padding buffer
	    to avoid data corruption. Corruption of padding memory doesn’t affect the
	    stack/program behaviour.
	 */
	usb_param.max_num_ep = 3 + 1;
	usb_param.mem_base = USB_STACK_MEM_BASE;
	usb_param.mem_size = USB_STACK_MEM_SIZE;

	/* Set the USB descriptors */
	desc.device_desc = (uint8_t *) &USB_DeviceDescriptor[0];
	desc.string_desc = (uint8_t *) &USB_StringDescriptor[0];
	/* Note, to pass USBCV test full-speed only devices should have both
	   descriptor arrays point to same location and device_qualifier set to 0.
	 */
	desc.high_speed_desc = (uint8_t *) &USB_FsConfigDescriptor[0];
	desc.full_speed_desc = (uint8_t *) &USB_FsConfigDescriptor[0];
	desc.device_qualifier = 0;

	/* USB Initialization */
	ret = USBD_API->hw->Init(&g_hUsb, &desc, &usb_param);
	if (ret == LPC_OK) {

		/*	WORKAROUND for artf32219 ROM driver BUG:
		    The mem_base parameter part of USB_param structure returned
		    by Init() routine is not accurate causing memory allocation issues for
		    further components.
		 */
		usb_param.mem_base = USB_STACK_MEM_BASE + (USB_STACK_MEM_SIZE - usb_param.mem_size);

		/* Init VCOM interface */
		ret = vcom_init(g_hUsb, &desc, &usb_param);
		if (ret == LPC_OK) {
			/*  enable USB interrupts */
			NVIC_EnableIRQ(USB0_IRQn);
			/* now connect */
			USBD_API->hw->Connect(g_hUsb, 1);
		}

	}

	/*-------------------- ADC Init --------------------*/
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 11, (IOCON_FUNC2 | IOCON_ADMODE_EN)); /* AD0 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 12, (IOCON_FUNC2 | IOCON_ADMODE_EN)); /* AD1 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 13, (IOCON_FUNC2 | IOCON_ADMODE_EN)); /* AD2 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 14, (IOCON_FUNC2 | IOCON_ADMODE_EN)); /* AD3 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 15, (IOCON_FUNC2 | IOCON_ADMODE_EN)); /* AD4 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 16, (IOCON_FUNC1 | IOCON_ADMODE_EN)); /* AD5 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 22, (IOCON_FUNC1 | IOCON_ADMODE_EN)); /* AD6 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 23, (IOCON_FUNC1 | IOCON_ADMODE_EN)); /* AD7 */

	Chip_ADC_Init(_LPC_ADC_ID, &ADCSetup);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH0, ENABLE);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH1, ENABLE);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH2, ENABLE);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH3, ENABLE);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH4, ENABLE);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH5, ENABLE);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH6, ENABLE);
	Chip_ADC_EnableChannel(_LPC_ADC_ID, ADC_CH7, ENABLE);
	Chip_ADC_Int_SetChannelCmd(_LPC_ADC_ID, ADC_CH7, ENABLE);
	NVIC_ClearPendingIRQ(ADC_IRQn);
	NVIC_EnableIRQ(ADC_IRQn);
	Chip_ADC_SetStartMode(_LPC_ADC_ID, ADC_START_ON_ADCTRIG0, ADC_TRIGGERMODE_RISING);

	/*-------------------- Timer32_0  Init --------------------*/
	Chip_TIMER_Init(LPC_TIMER32_0);
	timerFreq = Chip_Clock_GetSystemClockRate();
	Chip_TIMER_Reset(LPC_TIMER32_0);
	Chip_TIMER_MatchEnableInt(LPC_TIMER32_0, 0);
	Chip_TIMER_SetMatch(LPC_TIMER32_0, 0, ((timerFreq / (2*FS*NCH))-1));
	Chip_TIMER_ResetOnMatchEnable(LPC_TIMER32_0, 0);
	Chip_TIMER_ExtMatchControlSet(LPC_TIMER32_0, 0, TIMER_EXTMATCH_TOGGLE, 0);
	Chip_TIMER_Enable(LPC_TIMER32_0);
	/*----------------------- End of Init ------------------------*/

	while (1) {
		/* Check if host has connected and opened the VCOM port */
		if ((vcom_connected() != 0) && (prompt == 0)) {

			prompt = 1;
			//Board_LED_Set(0, true);
		}

		if (prompt) {

			rdSize = vcom_bread(&g_rxBuff[0], NRX);
			if (rdSize==NRX){

				if(GET_BIT(g_rxBuff[0], 7)){

					//if(!dataCapture){

					wr=0;
					dataCapture=true;
					Board_LED_Set(0, false);
					//}
				}
				else
				{
					dataCapture=false;
				}

			}
			if(captureReady1){


				for(int i=0;i<SSIZE;i++)
					vcom_write(&g_txBuff[i*PSIZE], PSIZE);
				captureReady1=false;


			}
			if(captureReady2){


				for(int i=0;i<SSIZE;i++)
					vcom_write(&g_txBuff[DSIZE2+(i*PSIZE)], PSIZE);
				captureReady2=false;


			}
		}
	}
}
